
# Step 1 : Read input data in R
commentsdata <- read.table("inputdata1.tsv", header=F, as.is=T, sep='\t', quote="")

comments <- commentsdata$V3

comments <- gsub("[[:punct:]]|[[:digit:]]", " ", comments)

comments <- gsub("[[:space:]]{2,}", " ", comments)

# Convert the text blobs to vector of words

comments <- strsplit(comments, split=" ")

# to check structure of the above list run str(head(comments))

# Step 2 : Read positive and negative opinion lexicon

pos_words <- scan("positive-words.txt", skip=35, sep='\n', what=character())

neg_words <- scan("negative-words.txt", skip=35, sep='\n', what=character())

# Step 3 : Measure the occurances of positive and negative words in each comment 
# We are removing the effect of length of the document here.

matched_pos <- sapply(comments, function(x) { sum(x %in% pos_words)/log(length(x))})

matched_neg <- sapply(comments, function(x) { sum(x %in% neg_words)/log(length(x))})

# Step 4 : Create and scale the final score

score <- matched_pos - matched_neg

#score <- as.vector(scale(score))

score <- round(score, 2)

# Step 5 : Explore the most positive and the most negative comments

commentsdata$score <- score 

commentsdata <- commentsdata[order(commentsdata$score), ] # Order by the score, lowest first

head(commentsdata$V2, 10)

tail(commentsdata$V2, 10)
