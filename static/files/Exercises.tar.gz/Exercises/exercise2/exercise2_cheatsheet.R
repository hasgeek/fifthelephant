library(tm)

# Import the documents in a corpus

mycorpus <- Corpus(DirSource(".", pattern="d_"), readerControl=list(language="en"))

# Transformations on the doc
mycorpus <- tm_map(mycorpus, removeNumbers)
mycorpus <- tm_map(mycorpus, removePunctuation)
mycorpus <- tm_map(mycorpus, stripWhitespace)
mycorpus <- tm_map(mycorpus, tolower)
mycorpus <- tm_map(mycorpus, removeWords, stopwords("en"))
#mycorpus <- tm_map(mycorpus, stemDocument)


# Simple Term Document Matrix

mytdm <- DocumentTermMatrix(mycorpus)

mytdm_mat <- as.matrix(mytdm)

# Inspect the simple matrix

mytdm_mat[c("d_camera1", "d_camera2", "d_washing_machine1", "d_washing_machine2"), c("camera", "lens", "wash", "performance")]
 
# Introduce TFIDF for better weighting

mycontrolist <- list(weighting = function(x) {weightTfIdf(x, normalize=T)}, bounds=list(global = c(2 , 25)), wordLengths=c(4, 12) )

mytdm <- DocumentTermMatrix(mycorpus, control=mycontrolist)

mytdm_mat <- as.matrix(mytdm) 

mytdm_scaled <- scale(mytdm_mat, center = FALSE, scale =sqrt(colSums(mytdm_mat^2)))

# Calculate distance between documents and use clustering

distance <- dist(mytdm_scaled, method='manhattan')

clusterfit <- hclust(d=distance, method='ward')

plot(clusterfit)
 
